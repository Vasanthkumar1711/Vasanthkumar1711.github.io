# career-website
The sort of frontpage for my resume

I began my work on this in an attempt to learn html/css and a bit of javascript. I work on it and update it when I can. Suggestions are welcome!
